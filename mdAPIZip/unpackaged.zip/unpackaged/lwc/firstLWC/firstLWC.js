import { LightningElement } from 'lwc';

export default class FirstLWC extends LightningElement {}