import { LightningElement } from 'lwc';

export default class AutoScroll extends LightningElement {}