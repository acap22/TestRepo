import { api, LightningElement } from 'lwc';

export default class Placeholder extends LightningElement {
    @api message
}