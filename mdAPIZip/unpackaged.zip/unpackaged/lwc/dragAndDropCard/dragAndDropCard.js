import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation'
export default class DragAndDropCard extends NavigationMixin(LightningElement) {
    @api record
    @api stage
   get isSameStage(){
       return this.stage === this.record.StageName
   }
   navigationOppHandler(event){
       event.preventDefault()
       console.log(event.target.dataset.id)
       this.navigateHandler(event.target.dataset.id, 'Opportunity') 
   }
   navigationAccHandler(event){
    event.preventDefault()
    console.log(event.target.dataset.id)
    this.navigateHandler(event.target.dataset.id, 'Account')
   }
   navigateHandler(Id, apiName){
    console.log('Id:'+Id +' Obj:'+apiName)
    this[NavigationMixin.Navigate]({
        type:'standard__recordPage',
        attributes:{
            recordId:Id,
            objectApiName:apiName,
            actionName:'view'
        }

    })
   }
   itemDragStart(){
       const event = new CustomEvent('itemdrag',{
           detail:this.record.Id
       })
       this.dispatchEvent(event)
   }
}