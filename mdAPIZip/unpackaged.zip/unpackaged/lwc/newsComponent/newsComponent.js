import { LightningElement, track } from 'lwc';
import retrieveNews from "@salesforce/apex/newsController.retrieveNews"
export default class NewsComponent extends LightningElement {
    @track result = [];
    @track selectedNews = {};
    @track isModalOpen = false;
    filterText = 'alstom';
    get modalBackDropClass(){
        console.log("inside backdrop: " + this.isModalOpen);
        return this.isModalOpen ? "slds-backdrop slds-backdrop_open" : "slds-backdrop";
    }
    get modalClass(){
        console.log("inside modal: " + this.isModalOpen);
        return this.isModalOpen ? "slds-modal slds-fade-in-open":"slds-modal";
    }
    handleClick(event){
        console.log(event.target.label)
        this.fetchNews()
    }
    /*connectedCallback(){
        this.fetchNews()
    }*/
    
    handleInputChange(event){
        console.log(event.detail.value)
        this.filterText = event.detail.value
    }

    fetchNews(){
        retrieveNews({newsFilter:this.filterText}).then(reponse=>{
            console.log(reponse)
            this.formatNewsData(reponse.articles)
        }).catch(error=>{
            console.error(error)
        })
    }
    formatNewsData(res){
        this.result = res.map((item, index)=>{
            let id = `news_${index+1}`
            let name = item.source.name
            return{...item, id:id, name:name}
        })
    }
    showModal(event){
        let id = event.target.dataset.item;
        this.result.forEach(item=>{
            if(item.id===id){
                this.selectedNews={...item}
            }
        })
        this.isModalOpen = true;
    }
    closeModal(){
        console.log("inside Closemodal: " + this.isModalOpen);
        this.isModalOpen = false;
        console.log("inside Closemodal: " + this.isModalOpen);
    }
    /*
    "articles":[
        {"source":
            {"id":"le-monde",
            "name":"Le Monde"},
        "author":"Elsa Conesa",
        "title":"Le rachat par EDF des anciennes turbines d’Alstom répare un « péché originel » d’Emmanuel Macron",
        "description":"Alors ministre de l’économie, le chef de l’Etat avait validé en 2014 la cession de la branche énergie d’Alstom à l’américain General Electric.",
        "url":"https://www.lemonde.fr/politique/article/2022/02/08/le-rachat-par-edf-des-anciennes-turbines-d-alstom-repare-un-peche-originel-d-emmanuel-macron_6112767_823448.html",
        "urlToImage":"https://img.lemde.fr/2022/02/08/646/0/4928/2461/1440/720/60/0/603fa30_280735997-000-par8181376.jpg",
        "publishedAt":"2022-02-08T09:18:39Z",
        "content":"Cela faisait partie des quelques dossiers « à boucler avant les élections », selon un membre du gouvernement. Sur le point de se concrétiser après des mois de discussions sous lil attentif de Bercy e… [+3055 chars]"}
    */
}