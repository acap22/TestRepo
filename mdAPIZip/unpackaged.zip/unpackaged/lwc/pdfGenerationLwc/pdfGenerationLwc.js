import generatePDF from '@salesforce/apex/pdfController.generatePDF'
import { LightningElement, api } from 'lwc';

export default class PdfGenerationLwc extends LightningElement {
    @api recordId
    imageUrl = 'https://www.designfreelogoonline.com/wp-content/uploads/2016/12/000782-link-3D-logo-design-online-free-3d-logo-maker-02.png'
    invoiceData={
        invoiceNo : '1234',
        invoiceCreated:'Jan 12, 2022',
        invoiceDue:'Mar 22, 2022',
        companyName:'AVDH Consulting',
        address1:'111 Queen Street',
        address2:'Bangaloew, India'

    }
    clientData={
        client:'XUIOS Limited',
        username:'Alex Giina',
        email:'alex@giina.com'
    }
    services=[
        {name:"Consultation Fee", amount:500.00},
        {name:"Service Fee", amount:100.00},
        {name:"Installation Fee", amount:3000.00}
    ]
    get totalAmount(){
        return this.services.reduce((total, service)=>{
            return total = total + service.amount
        },0)
    }
    pdfHandler(){
        let content = this.template.querySelector('.container')
        console.log(content.outerHTML)
        generatePDF({recordId:this.recordId, htmlData:content.outerHTML}).then(
            result=>{console.log("attachment id : ", result)
            window.open(`https://nosoftware-data-5215-dev-ed--c.documentforce.com/servlet/servlet.FileDownload?file=${result.Id}`)
            }).catch(error=>{console.error(error)})
    }
}