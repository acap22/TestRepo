import { LightningElement, wire } from 'lwc';
import getOpportunities from '@salesforce/apex/OpportunityController.getOpportunities'
export default class ChartDemo extends LightningElement {
    pieChartData
    pieChartLabels
    @wire(getOpportunities)
    opportunityHandler({data, error}){
        if(data){
            console.log(data)
            const result = data.reduce((JSON, values)=>({...JSON, [values.StageName]:(JSON[values.StageName]|0)+1}), {})
            //console.log(result)
            
            if(Object.keys(result)!= null){
                console.log('from inside if len:'+Object.keys(result).length)
                this.pieChartLabels = Object.keys(result)
                this.pieChartData = Object.values(result)
            }
            else{
                console.log('inside else: '+Object.keys(result).length)
            }
        }
        else{
            console.error(error)
        }
    }
}